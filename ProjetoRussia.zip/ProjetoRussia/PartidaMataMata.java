package projetorussia2018;

import java.util.LinkedList;

public class PartidaMataMata extends Partida {

    @Override
    public Placar JogarPartida(int TimeA, int TimeB) {
        int p1, p2;
        GeradorProbabilidade gp = new GeradorProbabilidade();
        Placar p;
        DistribuirCartoes(this.Times.get(TimeA));
        DistribuirCartoes(this.Times.get(TimeB));
        p = MarcarGols(this.Times.get(TimeA), this.Times.get(TimeB));
        p = DisputarPenaltis(p);
        ExibirResultados(this.Times.get(TimeA), this.Times.get(TimeB), p);
        return p;
    }

    @Override
    public Partida setTimes(LinkedList<Time> ListaTimes){
        try{
            Times = new LinkedList();
            this.Times = ListaTimes;
        } catch(Exception excecao){
            System.out.println();
        }
        return this;
    }

    private Placar DisputarPenaltis(Placar Resultado){
        int placarA, placarB;
        placarA = Resultado.getPlacarTimeA();
        placarB = Resultado.getPlacarTimeA();
        if(placarA == placarB){
            Placar p = MarcarGols(Resultado.getTimeA(), Resultado.getTimeB());
            if(p.getPlacarTimeA() == p.getPlacarTimeB()){
                return DisputarPenaltis(p);
            } else
                return p;
        } else 
            return Resultado;
    }
    
    @Override
    public LinkedList<Time> RodarFase(){
        LinkedList<Time> ListaAuxiliar;
        int fase = 0;
        while(Times.size() > 1){
            System.out.println("\nInicio da fase");
            ListaAuxiliar = new LinkedList<Time>();
            for(int i = 0; i < Times.size(); i += 2){
                Placar p = JogarPartida(i, (i+1));
                if(p.getPlacarTimeA() > p.getPlacarTimeB()){
                    ListaAuxiliar.add(p.getTimeA());
                } else {
                    ListaAuxiliar.add(p.getTimeB());
                }
            }
            Times = ListaAuxiliar;
        }
        return Times;
    }
}
