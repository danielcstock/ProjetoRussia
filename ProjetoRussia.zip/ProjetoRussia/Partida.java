package projetorussia2018;

import java.util.LinkedList;

public abstract class Partida {
    
    protected LinkedList<Time> Times;
    private final Observer obs = new Observer(this);

    public abstract Partida setTimes(LinkedList<Time> ListaTimes); 

    public abstract Placar JogarPartida(int TimeA, int TimeB);

    public abstract LinkedList<Time> RodarFase();

    public void DistribuirCartoes(Time A){
        GeradorProbabilidade gp = new GeradorProbabilidade();
        int p, cartoesAmarelos, cartoesVermelhos;
        
        p = gp.CalcularProbabilidade(A.getProbabilidadeCartoes());
        cartoesVermelhos = p%4;
        cartoesAmarelos = p - cartoesVermelhos;
        this.DarCartoesJogadores(A, cartoesAmarelos, cartoesVermelhos);
        obs.notificarTime(A);
    }

    private void DarCartoesJogadores(Time A, int cartoesAmarelos, int cartoesVermelhos){
        LinkedList<Esportista> jogadores = A.getJogadores();
        Jogador j;
        double totalP, indice;
        int i;
        while(cartoesAmarelos > 0){
            totalP = 0;
            for(i = 0; i < jogadores.size(); i++){
                j = (Jogador)jogadores.get(i);
                if(j.getCartoesAmarelo() < 2){
                    totalP += j.getProbabilidadeCartoes();
                }
            }
            indice = (Math.random()*totalP);
            totalP = 0;
            for(i = 0; (i < jogadores.size()) && (indice > totalP); i++){
                j = (Jogador)jogadores.get(i);
                if(j.getCartoesAmarelo() < 2){
                    totalP += j.getProbabilidadeCartoes();
                }
            }
            i--;
            j = (Jogador)jogadores.get(i);
            j.setCartaoAmarelo(1);
            cartoesAmarelos--;
        }
        while(cartoesVermelhos > 0){
            totalP = 0;
            for(i = 0; i < jogadores.size(); i++){
                j = (Jogador)jogadores.get(i);
                if(j.getCartoesVermelho() < 1 && j.getCartoesAmarelo() < 2){
                    totalP += j.getProbabilidadeCartoes();
                }
            }
            indice = (Math.random() * (totalP));
            totalP = 0;
            for(i = 0; (indice > totalP) && (i < jogadores.size()) ; i++){
                j = (Jogador)jogadores.get(i);
                if(j.getCartoesVermelho() < 1 && j.getCartoesAmarelo() < 2){
                    totalP += j.getProbabilidadeCartoes();
                }
            }
            i--;
            j = (Jogador)jogadores.get(i);
            j.setCartaoVermelho(1);
            cartoesVermelhos--;
        }
    }

    protected Placar MarcarGols(Time TimeA, Time TimeB){
        Placar p = new Placar(TimeA, TimeB);
        GeradorProbabilidade gp = new GeradorProbabilidade();
        p.setPlacarTimeA(gp.CalcularProbabilidade(TimeA.getProbabilidadeGols()));
        p.setPlacarTimeB(gp.CalcularProbabilidade(TimeB.getProbabilidadeGols()));
        return p;
    }
    
    protected void ExibirResultados(Time TimeA, Time TimeB, Placar Resultados) {
        System.out.println(TimeA.getNome() + " " + Resultados.getPlacarTimeA()
                            + " x " + Resultados.getPlacarTimeB() + " " + TimeB.getNome());
    }

    protected LinkedList<Time> OrdenarTimes(){
        LinkedList<Time> Classificacao = new LinkedList<Time>();
        Time primeiro, segundo;
        if(Times.get(0).getPontos() > Times.get(1).getPontos()){
            primeiro = Times.get(0);
        } else {
            primeiro = Times.get(1);
        }
        if(Times.get(0).getPontos() > Times.get(2).getPontos()){
            primeiro = Times.get(0);
        } 
        if(Times.get(0).getPontos() > Times.get(3).getPontos()){
            primeiro = Times.get(0);
        } 
        Times.remove(primeiro);
        
        if(Times.get(0).getPontos() > Times.get(1).getPontos()){
            segundo = Times.get(0);
        } else {
            segundo = Times.get(1);
        }
        if(Times.get(0).getPontos() > Times.get(2).getPontos()){
            segundo = Times.get(0);
        } 
        Classificacao.add(primeiro);
        Classificacao.add(segundo);
        return Classificacao;
    }
}
