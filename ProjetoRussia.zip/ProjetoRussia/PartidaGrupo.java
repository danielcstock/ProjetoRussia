package projetorussia2018;

import java.util.LinkedList;

public class PartidaGrupo extends Partida{
    
    @Override
    public Placar JogarPartida(int TimeA, int TimeB) {
        Placar p;
        GeradorProbabilidade gp = new GeradorProbabilidade();
        DistribuirCartoes(this.Times.get(TimeA));
        DistribuirCartoes(this.Times.get(TimeB));
        p = MarcarGols(this.Times.get(TimeA), this.Times.get(TimeB));
        ExibirResultados(this.Times.get(TimeA), this.Times.get(TimeB), p);
        MarcarPontuacao(p);
        return p;
    }
    
    protected void MarcarPontuacao(Placar Resultado){
        int placarA, placarB;
        Time timeA, timeB;
        placarA = Resultado.getPlacarTimeA();
        placarB = Resultado.getPlacarTimeB();
        timeA = Resultado.getTimeA();
        timeB = Resultado.getTimeB();
        if(placarA > placarB){
            timeA.setPontos(3);
        } else if(placarA < placarB){
            timeB.setPontos(3);
        } else {
            timeA.setPontos(1);
            timeB.setPontos(1);
        }
    }
    
    @Override
    public Partida setTimes(LinkedList<Time> ListaTimes) {
        try{
            Times = ListaTimes;
        } catch(Exception excecao){
            throw excecao;
        }
        return this;
    }

    @Override
    public LinkedList<Time> RodarFase(){
        Placar placarA, placarB;
        int k = 2, l = 3;
        for(int j = (1); j <= 3; j++){
            placarA = JogarPartida(0, j);
            placarB = JogarPartida(k, l);
            if(l == 3 && k == 1)
                l--;
            if(k == 2)
                k--;
        }
        return OrdenarTimes();
    }
}
