package projetorussia2018;

public class Placar {
    private Time TimeA, TimeB;
    int GolsTimeA = 0, GolsTimeB = 0;
    
    Placar(Time TimeA, Time TimeB){
        try{
            this.TimeA = TimeA;
            this.TimeB = TimeB;
        } catch (Exception excecao){
            throw excecao;
        }
    }

    public void setPlacarTimeA(int gols){
        this.GolsTimeA = gols;
    }

    public void setPlacarTimeB(int gols){
        this.GolsTimeB = gols;
    }

    public int getPlacarTimeA(){
        return this.GolsTimeA;
    }

    public int getPlacarTimeB(){
        return this.GolsTimeB;
    }
    
    public Time getTimeA(){
        return this.TimeA;
    }
    
    public Time getTimeB(){
        return this.TimeB;
    }
}