package projetorussia2018;

import java.util.LinkedList;

public class Time {

    private String Nome;
    private LinkedList<Esportista> Jogadores;
    private Double ProbabilidadeGols;
    private Double ProbabilidadeCartoes;
    private int Pontos;

    public Time setNome(String Nome){
        try{
            this.Nome = Nome;
            return this;
        } catch(ExceptionInInitializerError e){
            throw e;
        }
    }

    public Time setJogadores(LinkedList<Esportista> Jogadores){
        try{
            this.Jogadores = Jogadores;
            return this;
        } catch(ExceptionInInitializerError e){
            throw e;
        }
    }

    public void setProbabilidades(double probGols, double probCartoes){
        ProbabilidadeGols = probGols;
        ProbabilidadeCartoes = probCartoes;
    }
    
    public void setPontos(int p){
        if(p >= 0){
            this.Pontos = p;
        }
    }

    public double getProbabilidadeGols(){
        return this.ProbabilidadeGols;
    }
    
    public double getProbabilidadeCartoes(){
        return this.ProbabilidadeCartoes;
    }
    
    public String getNome(){
        return this.Nome;
    }
    
    public int getPontos(){
        return this.Pontos;
    }

    public LinkedList<Esportista> getJogadores(){
        return this.Jogadores;
    }

    public void calcularProbabilidadeGols(){
        double somaDasProbabilidades = 0;
        for (int i = 0; i<this.Jogadores.size(); i++){
            somaDasProbabilidades += this.Jogadores.get(i).getProbabilidadeGols();
        }
        somaDasProbabilidades = Math.sqrt(somaDasProbabilidades);
        this.ProbabilidadeGols = somaDasProbabilidades;
    }

    public void calcularProbabilidadeCartoes(){
        double somaDasProbabilidades = 0;
        for (int i = 0; i<this.Jogadores.size(); i++){
            somaDasProbabilidades += this.Jogadores.get(i).getProbabilidadeCartoes();
        }
        somaDasProbabilidades = Math.sqrt(somaDasProbabilidades);
        this.ProbabilidadeCartoes = somaDasProbabilidades;
    }
    
    public void recalcularProbabilidade(){
        double somaDasProbabilidades = 0;
        Jogador j;
        for (int i = 0; i < Jogadores.size(); i++){
            j = (Jogador)Jogadores.get(i);
            if(j.getCartoesAmarelo() < 2 && j.getCartoesVermelho() < 1)
                somaDasProbabilidades += j.getProbabilidadeGols();
        }
        somaDasProbabilidades = Math.sqrt(somaDasProbabilidades);
        this.ProbabilidadeGols = somaDasProbabilidades;
        zerarCartoes();
    }
    
    public void zerarCartoes(){
        Jogador j;
        for(int i = 0; i < Jogadores.size(); i++){
            j = (Jogador)Jogadores.get(i);
            while(j.getCartoesAmarelo() > 0){
                j.setCartaoAmarelo(-1);
            }
            while(j.getCartoesVermelho() > 0){
                j.setCartaoVermelho(-1);
            }
        }
    }
}
