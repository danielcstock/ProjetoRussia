package projetorussia2018;

public interface Esportista {

    public double getProbabilidadeGols();
    public double getProbabilidadeCartoes();
}