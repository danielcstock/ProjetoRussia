package projetorussia2018;

import java.util.LinkedList;

public class ProjetoRussia2018 {
    public static void main(String[] args) {
        
        /* Leitura do arquivo com os dados de entrada */
        LinkedList<Time> ListaTimesGrupos = new LinkedList();
        LinkedList<Time> ListaTimesMataMata = new LinkedList();
        LinkedList<Time> ListaAuxiliar;
        LeitorXML xmlReader = new LeitorXML();
        xmlReader.setArquivo("D:/escalacao.xml");
        ListaTimesGrupos = xmlReader.lerArquivo(ListaTimesGrupos);

        /* Inicio da fase de grupos */
        Partida p;
        System.out.println("Fase de Grupos:");
        char grupo = 65;
        for(int i = 0; i < 31; i += 4){
            System.out.println("\nGrupo " + grupo + ":");
            p = new PartidaGrupo();
            LinkedList<Time> lista = new LinkedList<Time>();
            lista.add((Time)ListaTimesGrupos.get(i));
            lista.add((Time)ListaTimesGrupos.get(i+1));
            lista.add((Time)ListaTimesGrupos.get(i+2));
            lista.add((Time)ListaTimesGrupos.get(i+3));
            p.setTimes(lista);
            ListaAuxiliar = p.RodarFase();
            ListaTimesMataMata.add(ListaAuxiliar.get(0));
            ListaTimesMataMata.add(ListaAuxiliar.get(1));
            grupo++;
        }

        /* Inicio da fase mata mata */
        p = new PartidaMataMata();
        p = p.setTimes(ListaTimesMataMata);
        System.out.println("\nFase Mata Mata:");
        ListaAuxiliar = p.RodarFase();
        
        /* Equipe vencedora */
        System.out.println("\nEquipe Vencedora da Copa do Mundo FIFA 2018:");
        System.out.println(ListaAuxiliar.getFirst().getNome());
    }
    
}
